﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using DemoApplication.Models;

namespace DemoApplication.Controllers
{
    public class ContactApiController : ApiController
    {
        private readonly SqlDbContext ObjDB = new SqlDbContext();

        public IEnumerable<Contact> Get()
        {
            return ObjDB.Contacts.ToList();
        }

        public Contact Get(int id)
        {
            return ObjDB.Contacts.Find(id);
        }

        public void Post([FromBody] List<string> val)
        {
            try
            {
                Contact obj = new Contact();
                obj.FirstName = val[1];
                obj.LastName = val[2];
                obj.PhoneNumber = val[3];
                obj.Email = val[4];
                obj.Status = Convert.ToBoolean(Convert.ToInt32(val[5]));
                obj.CreatedBy = Convert.ToInt32(val[6]);
                obj.CreatedDate = Convert.ToDateTime(val[7]);
                ObjDB.Contacts.Add(obj);
                ObjDB.SaveChanges();
            }
            catch (Exception) 
            {
                throw;
            }
        }

        public void patch([FromBody]Contact obj )
        {
            try
            {
                ObjDB.Entry(obj).State = System.Data.Entity.EntityState.Modified;
                ObjDB.SaveChanges();
            }
            catch (Exception ) 
            {
                throw;
            }
        }

        public void Put(List<string> val)
        {
            try
            {
                int id = Convert.ToInt32(val[3]);
                Contact obj = ObjDB.Contacts.Find(id);
                obj.FirstName = val[0];
                obj.LastName = val[1];
                obj.PhoneNumber = val[2];
                obj.Email = val[3];
                ObjDB.Contacts.Add(obj);
                ObjDB.Entry(obj).State = System.Data.Entity.EntityState.Modified;
                ObjDB.SaveChanges();
            }
            catch (Exception) 
            {
                throw;
            }
        }

        public void Delete(int id)
        {
            try
            {
                Contact obj = ObjDB.Contacts.Find(id);
                ObjDB.Contacts.Remove(obj);
                ObjDB.SaveChanges();
            }
            catch (Exception)
            {
                throw;
            }

        }
    }
}

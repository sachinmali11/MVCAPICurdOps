﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DemoApplication.Models;

namespace DemoApplication.Controllers
{
    public class ContactsController : Controller
    {
        ContactApiController db = new ContactApiController();
        // GET: Contacts
        public ActionResult Index()
        {
            return View(db.Get());
        }

        // GET: Contacts Details
        public ActionResult Details(int id = 0 )
        {
            
            Contact contact = db.Get(id);

            if (contact == null)
            {
                return HttpNotFound();
            }
            return View(contact);
        }

        // GET: Contacts Create
        public ActionResult Create()
        {
            return View();
        }


        // POST: Contacts Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ContactId,FirstName,LastName,Email,PhoneNumber,Status")] Contact contact)
        {
            if (ModelState.IsValid)
            {
                List<string> ContactList = new List<string>();
                ContactList.Add(contact.ContactId.ToString());
                ContactList.Add(contact.FirstName);
                ContactList.Add(contact.LastName);
                ContactList.Add(contact.PhoneNumber);
                ContactList.Add(contact.Email);
                ContactList.Add(Convert.ToInt32(contact.Status).ToString());
                ContactList.Add("1");
                ContactList.Add(DateTime.Now.ToShortDateString());
                db.Post(ContactList);
                return RedirectToAction("Index");
            }

            return View(contact);
        }

        // GET: Contacts Edit
        public ActionResult Edit(int id = 0)
        {
            Contact contact = db.Get(id);
            if (contact == null)
            {
                return HttpNotFound();
            }
            return View(contact);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ContactId,FirstName,LastName,Email,PhoneNumber,Status")] Contact contact)
        {
            if (ModelState.IsValid)
            {
                contact.CreatedDate = Convert.ToDateTime(System.DateTime.Now.ToShortDateString());
                db.patch(contact);
                return RedirectToAction("Index");
            }
            return View(contact);
        }

        // GET: Contacts Delete
        public ActionResult Delete(int id=0)
        {
            Contact contact = db.Get(id);
            if (contact == null)
            {
                return HttpNotFound();
            }
            return View(contact);
        }

        // POST: Contacts Delete
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            db.Delete(id);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
